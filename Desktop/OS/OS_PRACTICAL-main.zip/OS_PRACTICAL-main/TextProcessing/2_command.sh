awk '{print $2}' data.txt
